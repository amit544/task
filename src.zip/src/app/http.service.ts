// import { Injectable } from '@angular/core';
// // import { HttpClient } from 'selenium-/http';
// import { HttpClient } from '@angular/common/http'

// @Injectable({
//   providedIn: 'root'
// })
// export class HttpService {

//   constructor(private http:HttpClient) { }
//  data()
//   {
//     return  this.http.get<any[]>(' https://randomuser.me/api/?results=100')
//   }
// }
